Dont delete this folder or anything in it!
EVEN IF IT IS EMPTY!
Create a file named "productkey.txt" to get the product key and to go ahead in the Cmd windnow!
Thanks for reading.
